# «КОМПЛАЕНС-КАДР» v10.4 (Тузатилган барқарор версия)

Кадастр агентлиги ва Давлат кадастрлари палатаси тизимида номзодлар ҳамда собиқ ходимларни комплаенс текширувидан ўтказиш, ИЦ судланганлик ҳолатини аниқлаш ва A4 Маълумотнома шакллантириш тизими.

## Кириш учун бошланғич логин ва пароллар

| Роль | Логин | Парол |
| :--- | :--- | :--- |
| Коррупцияга қарши курашиш бўлими (Админ) | `admin` | `Komplayens2026!` |
| Бўлим бошлиғи | `zaripov` | `Rahbar2026!` |
| Кадрлар бўлими (HR) | `kadr_jizzax` | `Kadr2026!` |
| Раҳбар кузатувчи | `rahbariyat` | `Kuzatuv2026!` |

## Supabase SQL созламаси

Supabase даشبордида **SQL Editor** га кириб, қуйидаги кодни **Run** қилинг:

```sql
CREATE TABLE IF NOT EXISTS komplayens_store (
  id TEXT PRIMARY KEY,
  payload JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE komplayens_store ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow all access" ON komplayens_store;
CREATE POLICY "Allow all access"
  ON komplayens_store FOR ALL
  USING (true) WITH CHECK (true);

ALTER TABLE komplayens_store REPLICA IDENTITY FULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'komplayens_store'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE komplayens_store;
  END IF;
END $$;
```
